﻿using Microsoft.AspNetCore.Mvc;
using WebApplication3.Models;

namespace WebApplication3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Logincontroller : ControllerBase
    {
        private CombineContext _combineContext = new CombineContext();

        [HttpGet]
        public List<Uye> Adminmi()
        {
            var kullanicilar = (from Kullanici in _combineContext.Kullanicilar
                                where Kullanici.KullaniciTipi != "Admin"
                                select Kullanici).ToList();
            // normalde json formatına cevirip gondermem lazım  [ApiController] bunu otomatik yapıyor
            return Uye;
        }
    }
}
}
