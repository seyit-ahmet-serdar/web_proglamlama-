﻿namespace WebApplication3.Models
{
    public class Uye
    {
        public bool Adminmi {  get; set; }  
    }
}
