﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace WebApplication3.Models
{
   
        public class ApplicationContext : DbContext
        {
        internal readonly object uyeler;

        public ApplicationContext(DbContextOptions options) : base(options)
            {
            }
            public DbSet<Uye> uye { get; set; }
        }
    
}
